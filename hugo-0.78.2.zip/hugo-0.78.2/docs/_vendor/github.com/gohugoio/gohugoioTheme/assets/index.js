require("typeface-muli")
import styles from './css/main.css';
import './js/clipboardjs.js'
import './js/codeblocks.js'
import './js/docsearch.js'
import './js/hljs.js'
import './js/lazysizes.js'
import './js/menutoggle.js'
import './js/scrolldir.js'
import './js/smoothscroll.js'
import './js/tabs.js'
import './js/nojs.js'
