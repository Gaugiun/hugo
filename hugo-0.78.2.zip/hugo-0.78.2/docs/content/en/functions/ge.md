---
title: ge
linktitle: ge
description: Returns the boolean truth of arg1 >= arg2.
godocref:
date: 2017-07-26
publishdate: 2017-07-26
lastmod: 2017-07-26
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [operators,logic]
signature: ["ge ARG1 ARG2"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---


```
{{ if ge 10 5 }}true{{ end }}
```
