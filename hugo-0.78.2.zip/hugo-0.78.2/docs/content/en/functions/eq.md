---
title: eq
linktitle: eq
description: Returns the boolean truth of arg1 == arg2.
godocref:
date: 2017-02-01
publishdate: 2017-02-01
lastmod: 2017-02-01
categories: [functions]
menu:
  docs:
    parent: "functions"
keywords: [operators,logic]
signature: ["eq ARG1 ARG2"]
workson: []
hugoversion:
relatedfuncs: []
deprecated: false
aliases: []
---


```
{{ if eq .Section "blog" }}current{{ end }}
```
